import torch
import json
import re
from pathlib import Path

class SimpleTextClassifier:
    def __init__(self):
        self.word_to_idx = {}
        self.word_embeddings = None
        self.class_prototypes = None
        self.incidents = []
        self.embedding_dim = 80
        self.similarity_threshold = 0.55  

    def _tokenize(self, text):
        # Сохраняем цифры и заменяем № на слово "номер" для лучшей семантики
        text = text.replace("№", " номер ")
        text = re.sub(r'[^а-яА-ЯёЁ0-9 ]', ' ', text.lower())
        return [w for w in text.split() if w]

    def train(self, data_path: Path, model_path: Path, epochs=400, lr=0.02):
        with open(data_path, encoding="utf-8") as f:
            self.incidents = json.load(f)

        texts, labels = [], []
        for label, item in enumerate(self.incidents):
            texts.append(item["incident"])
            labels.append(label)
            for alt in item.get("alternatives", []):
                texts.append(alt)
                labels.append(label)

        vocab = set()
        tokenized = []
        for t in texts:
            words = self._tokenize(t)
            tokenized.append(words)
            vocab.update(words)
        self.word_to_idx = {w: i for i, w in enumerate(vocab)}

        V, C = len(self.word_to_idx), len(self.incidents)
        self.word_embeddings = torch.randn(V, self.embedding_dim, requires_grad=True)
        self.class_prototypes = torch.randn(C, self.embedding_dim, requires_grad=True)
        label_tensor = torch.tensor(labels)

        print(f"Обучение модели: {len(texts)} примеров, {V} слов, {C} классов...")
        for epoch in range(epochs):
            for i, words in enumerate(tokenized):
                if not words:
                    vec = torch.zeros(self.embedding_dim)
                else:
                    indices = [self.word_to_idx[w] for w in words if w in self.word_to_idx]
                    vec = self.word_embeddings[torch.tensor(indices)].mean(dim=0) if indices else torch.zeros(self.embedding_dim)

                vec_norm = vec / (vec.norm(p=2, dim=0, keepdim=True) + 1e-8)
                proto_norm = self.class_prototypes / (self.class_prototypes.norm(p=2, dim=1, keepdim=True) + 1e-8)
                logits = torch.mv(proto_norm, vec_norm) * 10.0

                max_logit = logits.max()
                log_sum_exp = torch.log(torch.sum(torch.exp(logits - max_logit))) + max_logit
                loss = -(logits[label_tensor[i]] - log_sum_exp)
                loss.backward()

                with torch.no_grad():
                    self.word_embeddings -= lr * self.word_embeddings.grad
                    self.class_prototypes -= lr * self.class_prototypes.grad
                    self.word_embeddings.grad.zero_()
                    self.class_prototypes.grad.zero_()

        self.word_embeddings = self.word_embeddings.detach()
        self.class_prototypes = self.class_prototypes.detach()
        torch.save({
            'word_to_idx': self.word_to_idx,
            'word_embeddings': self.word_embeddings,
            'class_prototypes': self.class_prototypes,
            'incidents': self.incidents,
            'embedding_dim': self.embedding_dim,
            'similarity_threshold': self.similarity_threshold
        }, model_path)
        print(f" Модель успешно обучена и сохранена в: {model_path}")

    def load(self, model_path: Path):
        if not model_path.exists():
            raise FileNotFoundError(f"Модель не найдена: {model_path}. Запустите 'python backend/ml_model.py' для обучения.")
        data = torch.load(model_path, map_location='cpu')
        self.word_to_idx = data['word_to_idx']
        self.word_embeddings = data['word_embeddings']
        self.class_prototypes = data['class_prototypes']
        self.incidents = data['incidents']
        self.embedding_dim = data['embedding_dim']
        self.similarity_threshold = data['similarity_threshold']

    def predict(self, text: str):
        if self.word_embeddings is None:
            raise RuntimeError("Модель не загружена! Вызовите .load() сначала.")

        #  ПЕРВОЕ: проверка точного совпадения (регистронезависимо)
        clean_input = text.strip()
        for item in self.incidents:
            if clean_input == item["incident"]:
                result = item.copy()
                result.update({"confidence": 1.0, "is_recognized": True})
                return result
            for alt in item.get("alternatives", []):
                if clean_input == alt:
                    result = item.copy()
                    result.update({"confidence": 1.0, "is_recognized": True})
                    return result

        # Второе: семантический поиск
        words = self._tokenize(text)
        if not words:
            return self._fallback(0.0)

        indices = [self.word_to_idx[w] for w in words if w in self.word_to_idx]
        input_vec = self.word_embeddings[torch.tensor(indices)].mean(dim=0) if indices else torch.zeros(self.embedding_dim)

        input_norm = input_vec / (input_vec.norm(p=2, dim=0, keepdim=True) + 1e-8)
        proto_norm = self.class_prototypes / (self.class_prototypes.norm(p=2, dim=1, keepdim=True) + 1e-8)
        similarities = torch.mv(proto_norm, input_norm)
        best_score = similarities.max().item()
        best_idx = similarities.argmax().item()

        if best_score < self.similarity_threshold:
            return self._fallback(best_score)
        else:
            result = self.incidents[best_idx].copy()
            result.update({"confidence": round(best_score, 3), "is_recognized": True})
            return result

    def _fallback(self, confidence: float):
        return {
            "id": None,
            "incident": "Инцидент не распознан",
            "response_steps": [
                "1. Опишите ситуацию подробнее.",
                "2. Укажите место (цех, участок), оборудование, признаки (дым, шум, утечка и т.п.).",
                "3. Повторите запрос или свяжитесь с диспетчером."
            ],
            "memo_file": None,
            "confidence": round(confidence, 3),
            "is_recognized": False
        }


# ==========================================
# Автоматическое обучение при запуске файла
# ==========================================
if __name__ == "__main__":
    DATA_PATH = Path(__file__).parent.parent / "data" / "incidents.json"
    MODEL_PATH = Path(__file__).parent.parent / "data" / "model.pth"

    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Файл данных не найден: {DATA_PATH}")

    classifier = SimpleTextClassifier()
    classifier.train(
        data_path=DATA_PATH,
        model_path=MODEL_PATH,
        epochs=400,
        lr=0.02
    )