from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBearer
from pydantic import BaseModel, EmailStr
from passlib.context import CryptContext
import jwt
from jwt.exceptions import InvalidTokenError
from datetime import datetime, timedelta
from app.database import get_db_connection, init_db
from dotenv import load_dotenv
import os
from typing import Optional
# от ML
from ml_model import SimpleTextClassifier
from pathlib import Path
from fastapi.responses import FileResponse
from fastapi import File, UploadFile
# Загружаем .env
load_dotenv()

app = FastAPI(
    title="Auth API",
    description="API для аутентификации пользователей",
    version="1.0.0"
)

# Настройки JWT
SECRET_KEY = os.getenv("SECRET_KEY", "fallback-secret-key")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Настройка шифрования паролей
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Модели Pydantic
class UserRegister(BaseModel):
    email: EmailStr
    password: str
    confirm: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    email: str

class Token(BaseModel):
    access_token: str
    token_type: str

# Модель запроса 
class QueryRequest(BaseModel):
    text: str

# Инициализация таблицы при старте
@app.on_event("startup")
async def startup_event():
    init_db()

# Функции для работы с паролями
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

# Создание JWT токена
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# Проверка JWT токена
async def get_current_user(credentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("user_id")
        email = payload.get("email")

        if not user_id or not email:
            raise HTTPException(status_code=401, detail="Токен недействителен")

        return {"user_id": user_id, "email": email}

    except InvalidTokenError:
        raise HTTPException(status_code=401, detail="Недействительный или просроченный токен")

# ✅ Регистрация
@app.post("/register", status_code=201)
async def register(user_data: UserRegister):
    if user_data.password != user_data.confirm:
        raise HTTPException(status_code=400, detail="Пароли не совпадают")

    if len(user_data.password) < 6:
        raise HTTPException(status_code=400, detail="Пароль должен быть не менее 6 символов")

    hashed_password = get_password_hash(user_data.password)

    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO users (email, password_hash) VALUES (%s, %s) RETURNING id",
            (user_data.email, hashed_password)
        )
        user = cur.fetchone()
        conn.commit()
        return {"message": "Регистрация успешна", "user_id": user["id"]}

    except Exception:
        raise HTTPException(status_code=409, detail="Пользователь с таким email уже существует")
    finally:
        cur.close()
        conn.close()

# 🔑 Авторизация
@app.post("/login")
async def login(user_data: UserLogin):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE email = %s", (user_data.email,))
    user = cur.fetchone()
    cur.close()
    conn.close()

    if not user or not verify_password(user_data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Неверный email или пароль")

    token = create_access_token(
        data={"user_id": user["id"], "email": user["email"]},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )

    return {"message": "Успешный вход", "access_token": token, "token_type": "bearer"}

# 👤 Профиль
@app.get("/profile")
async def profile(current_user: dict = Depends(get_current_user)):
    return current_user

# 🚪 Выход
@app.post("/logout")
async def logout(current_user: dict = Depends(get_current_user)):
    return {"message": "Вы вышли из системы"}
@app.get("/")
def root():
    return {"message": "API is running 🚀"}


#от ML Модель ИИ (загружается один раз при старте)
PROJECT_ROOT = Path(__file__).parent.parent
MODEL_PATH = PROJECT_ROOT / "data" / "model.pth"
TEMPLATES_DIR = PROJECT_ROOT / "templates"
TEMPLATES_DIR.mkdir(exist_ok=True)

ai_model = SimpleTextClassifier()
try:
    ai_model.load(MODEL_PATH)
except Exception as e:
    print(f" Модель не загружена: {e}")




# 🔒 1. Эндпоинт нейросети — ТОЛЬКО для авторизованных
@app.post("/bot/query")
async def bot_query(request: QueryRequest, current_user: dict = Depends(get_current_user)):
    try:
        incident = ai_model.predict(request.text)

        if not incident.get("is_recognized"):
            return {
                "incident_id": None,
                "title": "Инцидент не распознан",
                "response": (
                    " **Инцидент не распознан**\n\n"
                    "Пожалуйста, опишите ситуацию подробнее:\n"
                    "• Укажите цех, оборудование, признаки (дым, шум, утечка и т.п.)\n"
                    "• Пример: «В цехе №3 из трубы идёт пар»"
                ),
                "file_link": None
            }

        incident_id = incident["id"]
        memo_file = f"/storage/download/memo_{incident_id:03d}.txt"
        steps = "\n".join(f"• {step}" for step in incident["response_steps"])

        return {
            "incident_id": incident_id,
            "title": incident["incident"],
            "response": (
                f" Обнаружен инцидент №{incident_id}: **{incident['incident']}**\n\n"
                f"**Рекомендуемые действия:**\n{steps}\n\n"
                f" Прикреплён файл с подробностями."
            ),
            "file_link": memo_file
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка модели: {str(e)}")


# 📁 Хранилище — все методы только для авторизованных

@app.get("/storage/files")
async def list_files(current_user: dict = Depends(get_current_user)):
    files = [f.name for f in TEMPLATES_DIR.iterdir() if f.is_file()]
    return {"files": sorted(files)}

@app.post("/storage/upload")
async def upload_file(file: UploadFile = File(...), current_user: dict = Depends(get_current_user)):
    file_path = TEMPLATES_DIR / file.filename
    with open(file_path, "wb") as buffer:
        buffer.write(file.file.read())
    return {"filename": file.filename, "status": "uploaded"}

@app.get("/storage/download/{filename}")
async def download_file(filename: str, current_user: dict = Depends(get_current_user)):
    if ".." in filename or filename.startswith("/") or not filename.endswith(".txt"):
        raise HTTPException(status_code=400, detail="Недопустимое имя файла")
    file_path = TEMPLATES_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Файл не найден")
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type='text/plain',
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@app.delete("/storage/delete/{filename}")
async def delete_file(filename: str, current_user: dict = Depends(get_current_user)):
    file_path = TEMPLATES_DIR / filename
    if file_path.exists():
        file_path.unlink()
        return {"status": "deleted", "filename": filename}
    raise HTTPException(status_code=404, detail="Файл не найден")

@app.get("/storage/search")
async def search_files(query: str, current_user: dict = Depends(get_current_user)):
    query = query.lower().strip()
    if not query:
        return {"results": []}
    results = []
    for file in TEMPLATES_DIR.iterdir():
        if file.is_file():
            try:
                content = file.read_text(encoding="utf-8").lower()
                if query in content:
                    results.append(file.name)
            except Exception:
                continue
    return {"results": sorted(results)}